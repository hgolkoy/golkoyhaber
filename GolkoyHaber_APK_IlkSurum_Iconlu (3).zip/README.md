# GölköyHaber Android APK

İlk sürüm Android proje iskeletidir. GölköyHaber markası, kategori akışı ve kaynak merkezi hazırdır.

## Yayın mimarisi

Kaynaklar → Haber Motoru → Filtre + Mükerrer Kontrol → Editör Onayı → APK + Web + Facebook Sayfası

Facebook otomatik yayın hedefi:
`https://www.facebook.com/habergolkoy52`

## Önemli güvenlik notu

Facebook erişim tokenı APK içine konulmaz. Otomatik Facebook Page paylaşımı backend üzerinden yapılmalıdır. APK yalnızca yayın durumunu/sonuçlarını backend'den almalıdır.

## Derleme

GitHub Actions içindeki `.github/workflows/build-apk.yml` ile `app-debug.apk` oluşturulabilir.

## Sonraki entegrasyon

- Backend/API
- Dinamik kaynak yönetimi
- RSS/web kaynakları
- Facebook Page yayın servisi
- Editör onay paneli
- Firebase/uygulama bildirimleri
- Gerçek Gölköy fotoğrafları ve logo
